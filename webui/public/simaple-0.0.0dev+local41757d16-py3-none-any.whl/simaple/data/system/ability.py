import json
from pathlib import Path

from simaple.core.jobtype import JobType
from simaple.system.ability import AbilityLine


def get_best_ability(jobtype: JobType) -> list[AbilityLine]:
    with open(Path(__file__).parent / "ability_fixed.json", encoding="utf-8") as f:
        best_abilities = json.load(f)

    ability_lines = best_abilities[jobtype.value]

    return [AbilityLine.model_validate(line) for line in ability_lines]
