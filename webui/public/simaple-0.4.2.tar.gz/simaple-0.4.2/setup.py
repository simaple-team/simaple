# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['simaple',
 'simaple.character',
 'simaple.container',
 'simaple.core',
 'simaple.data',
 'simaple.data.ability',
 'simaple.data.artifact',
 'simaple.data.baseline',
 'simaple.data.doping',
 'simaple.data.jobs',
 'simaple.data.jobs.definitions',
 'simaple.data.system',
 'simaple.gear',
 'simaple.gear.blueprint',
 'simaple.gear.compute',
 'simaple.gear.improvements',
 'simaple.metric',
 'simaple.optimizer',
 'simaple.request',
 'simaple.request.adapter',
 'simaple.request.application',
 'simaple.request.schema',
 'simaple.request.translator',
 'simaple.request.translator.asset',
 'simaple.request.translator.kms',
 'simaple.simulate',
 'simaple.simulate.component',
 'simaple.simulate.component.specific',
 'simaple.simulate.component.trait',
 'simaple.simulate.policy',
 'simaple.simulate.report',
 'simaple.simulate.strategy',
 'simaple.spec',
 'simaple.system',
 'simaple.wasm',
 'simaple.wasm.models']

package_data = \
{'': ['*'],
 'simaple.data': ['baseline/resources/*',
                  'baseline/spec/*',
                  'jobs/resources/*',
                  'jobs/resources/adele/*',
                  'jobs/resources/archmagefb/*',
                  'jobs/resources/archmagetc/*',
                  'jobs/resources/bishop/*',
                  'jobs/resources/components/*',
                  'jobs/resources/components/classes/*',
                  'jobs/resources/dualblade/*',
                  'jobs/resources/mechanic/*',
                  'jobs/resources/soulmaster/*',
                  'jobs/resources/windbreaker/*'],
 'simaple.gear': ['resources/*']}

install_requires = \
['PyYAML>=6.0,<7.0',
 'SQLAlchemy>=1.4.45,<2.0.0',
 'aiohttp>=3.10.1,<4.0.0',
 'fire>=0.4.0,<0.5.0',
 'lark>=1.1.7,<2.0.0',
 'loguru>=0.5.3,<0.6.0',
 'numpy>=1.22.3,<2.0.0',
 'pydantic-settings>=2.0.3,<3.0.0',
 'pydantic>=2.4.2,<3.0.0',
 'pyfunctional>=1.5.0,<2.0.0',
 'requests>=2.26.0,<3.0.0',
 'scikit-learn>=1.0.2,<2.0.0',
 'scipy>=1.11.2,<2.0.0']

entry_points = \
{'console_scripts': ['simaple-simulate = scripts.simulate:run_from_cli']}

setup_kwargs = {
    'name': 'simaple',
    'version': '0.4.2',
    'description': 'Maplestory calculation / Simulation library',
    'long_description': '[![kr](https://img.shields.io/badge/lang-kr-red.svg)](README.md)\n[![en](https://img.shields.io/badge/lang-en-red.svg)](README.en.md)\n\n# simaple: Simulation library for Maplestory\n\n`simaple` 은 메이플스토리 내 전투 환경을 분석히기 위한 라이브러리입니다. \n\nsimaple은 클라이언트 리소스를 바탕으로 메이플스토리 내 직업의 시뮬레이션 환경을 구성하고, 적절한 전투 시나리오를 설계하여 스킬별 딜 비중 및 기대 DPM을 계산할 수 있도록 합니다.\n\n## Install from source\n\n```\ngit clone https://github.com/simaple-team/simaple\npoetry install\n```\n\n## Run Simulation\n\n```\npoetry run python scripts/simulate.py $PLAN_FILEPATH\n# or\nsimaple-simulate $PLAN_FILEPATH\n\n## example\npoetry run python scripts/simulate.py plans/30s/bishop.simaple\nsimaple-simulate plans/30s/bishop.simaple\n```\n\n\n## Web Client\n\nsimaple은 시뮬레이션을 쉽게 진행하기 위한 웹 인터페이스 또한 제공합니다.\n\n![image](https://user-images.githubusercontent.com/39217532/222165238-00926269-e581-4cd6-8e4c-aef5cff8e4ce.gif)\n- 웹 클라이언트는 [simaple/web](https://github.com/simaple-team/web) 에서 설치할 수 있습니다.\n\n\n## Package Install\n\n- `pip install simaple`\n\n## Documentation\n\n- https://simaple.readthedocs.io/en/latest/\n\n\n### Community\n\n- [Discord](https://discord.gg/5hgN5EbyA4)\n- [Slack](https://join.slack.com/t/maplestorydpmcalc/shared_invite/zt-1lwi3l97o-EH0R9~W97SB8TjsoXnpzpQ)\n\n\n## Developments & Contribution\n\n- See [CONTRIBUTING](CONTRIBUTING.md)\n\n## 지원되는 기능\n\n### 인게임 시뮬레이션\n- interactive한 시뮬레이션 환경 생성\n  - 쿨타임 감소 효과, 버프 지속시간 증가, 코어 강화 등 인 게임내 존재하는 모든 변수를 적용한 시뮬레이션 환경을 구축 가능\n- 시뮬레이션 진행 결과에 대한 분석\n  - DPM 계산\n  - 스킬 별 점유율 계산\n  - 전체 시뮬레이션 결과를 human-readable format으로 출력하여 custom 분석 \n\n### 아이템 관련\n- 스타포스 및 주문서 강화 적용 시 기대되는 아이템 성능 계산 \n- GearBlueprint를 통해, 환산 주스텟 등에 사용되는 기준 캐릭터 스펙의 성능 계산\n- 환산 주스텟 계산, 스텟별 효율 계산\n\n### 홈페이지 연동\n- 홈페이지로부터 정보 공개에 동의한 캐릭터를 simaple object로 로드 기능\n',
    'author': 'meson324',
    'author_email': 'meson324@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'https://github.com/simaple-team/simaple',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<3.13',
}


setup(**setup_kwargs)
