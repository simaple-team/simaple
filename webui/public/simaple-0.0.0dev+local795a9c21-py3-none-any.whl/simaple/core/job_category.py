import enum


class JobCategory(enum.IntEnum):
    warrior = 0
    magician = 1
    archer = 2
    thief = 3
    pirate = 4
