from simaple.data.jobs.builtin import get_skill_profile

__all__ = [
    "get_skill_profile",
]
