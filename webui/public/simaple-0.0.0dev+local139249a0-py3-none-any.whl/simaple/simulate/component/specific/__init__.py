# ruff: noqa: F401

import simaple.simulate.component.specific.adele
import simaple.simulate.component.specific.archmagefb
import simaple.simulate.component.specific.archmagetc
import simaple.simulate.component.specific.bishop
import simaple.simulate.component.specific.common_v
import simaple.simulate.component.specific.cygnus
import simaple.simulate.component.specific.dualblade
import simaple.simulate.component.specific.flora
import simaple.simulate.component.specific.magician
import simaple.simulate.component.specific.mechanic
import simaple.simulate.component.specific.pirate
import simaple.simulate.component.specific.soulmaster
import simaple.simulate.component.specific.thief
import simaple.simulate.component.specific.windbreaker
